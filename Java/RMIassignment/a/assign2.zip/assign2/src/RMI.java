import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

/**
 * Created by Albert on 4/7/2015.
 */
public interface RMI extends Remote {

    public String getName() throws RemoteException;

    public ArrayList<String> getNaics() throws RemoteException;

}
